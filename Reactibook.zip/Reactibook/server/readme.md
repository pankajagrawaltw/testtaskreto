PORT=5000
MONGO_URL='mongodb://localhost:27017/Test-Task'
BASE_URL= http://localhost:5000/

How To Run  Back-End Server

1) Install dependencies run command in server folder

npm install
npm install nodemon -g

2) To Start Back-End Server
nodemon app.js