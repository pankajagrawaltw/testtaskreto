const { date } = require("joi");
const mongoose = require("mongoose");
const Post = require("../models/post");

module.exports.addPost = (fileName, data) => {
    console.log(" data.file", fileName);
    return new Promise((resolve, reject) => {
        let currentDate = new Date();
        let currentMonth = currentDate.getMonth() + 1;
        currentMonth = currentMonth <= 9 ? "0" + currentMonth : currentMonth;
        let currentDay = currentDate.getDate();
        currentDay = currentDay <= 9 ? "0" + currentDay : currentDay;
        let currentYear = currentDate.getFullYear();
        let relPath = "uploads" + '/' + currentYear + '/' + currentMonth + '/' + currentDay + '/' + encodeURIComponent(fileName);
        const post = new Post({
            userID: data.userID,
            postTitle: data.postTitle,
            postType: data.postType,
            postDescription: data.postDescription,
            postImage: process.env.BASE_URL + relPath,
        }).save().then((postResult) => {
            const responseData = {
                'status': 200,
                'success': true,
                'Data': postResult,
                'message': 'Post Created Successfully.',
            }
            resolve(responseData)

        }).catch((err) => reject('Requested resource not found'));
    });
}

module.exports.getAllPostsDetails = (postType) => {
    return new Promise((resolve, reject) => {
        if (postType) {
            Post.find({
                postType: postType
            }).sort({ createdAt: 1 }).then((requestResult) => {
                if (requestResult == null) {
                    const responseData = {
                        status: 201,
                        'success': false,
                        'message': 'Posts data not found.',

                    }
                    resolve(responseData)
                } else {
                    const responseData = {
                        'status': 200,
                        'success': true,
                        'message': 'Posts data get Successfully.',
                        "totalCount": requestResult.length,
                        "data": requestResult
                    }
                    resolve(responseData)
                }
            }).catch((err) => reject('Requested resource not found'));
        } else {
            Post.find({}).sort({ createdAt: 1 }).then((requestResult) => {
                if (requestResult == null) {
                    const responseData = {
                        status: 201,
                        'success': false,
                        'message': 'Post data not found.',

                    }
                    resolve(responseData)
                } else {
                    const responseData = {
                        'status': 200,
                        'success': true,
                        'message': 'Post data get Successfully.',
                        "totalCount": requestResult.length,
                        "data": requestResult
                    }
                    resolve(responseData)
                }
            }).catch((err) => reject('Requested resource not found'));
        }

    });
}


module.exports.postUpdate = (data) => {
    return new Promise((resolve, reject) => {
        Post.findOneAndUpdate({
            _id: data.postId
        }, {
            '$set': data
        }, {
            'new': true
        }).then((result) => {
            if (result == null) {
                const responseData = {
                    status: 201,
                    'success': false,
                    'message': 'postId not found.',
                }
                resolve(responseData)
            } else {
                const responseData = {
                    status: 200,
                    'success': true,
                    'message': 'Post Update successfully.',
                    'data': result,
                }
                resolve(responseData)
            }
        }).catch((error) => reject(error + ' Fail to update profileId'))
    })
};


module.exports.deletePost = (data) => {
    return new Promise((resolve, reject) => {
        Post.findOneAndDelete({
            _id: data.postId
        }).then((result) => {
            if (result == null) {
                const responseData = {
                    'success': false,
                    'message': 'postId not found.',
                }
                resolve(responseData)
            } else {
                const responseData = {
                    'success': true,
                    'message': ' Post deleted Successfully.'
                    //user: result
                }
                resolve(responseData)
            }
        }).catch((error) => reject('Failed to find postId'))
    })
};