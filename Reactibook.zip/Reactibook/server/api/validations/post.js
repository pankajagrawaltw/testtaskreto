const express = require("express");
const router = express.Router();
const Joi = require('@hapi/joi');
const Post = require('../controllers/post');


module.exports.createPost = (req, res, next) => {
    // console.log(" data.file", req.file.filename);

    //@ start validation
    let fileName = req.file.filename
    let requestedData = req.body;
    console.log("requestedData", requestedData);

    // define the validation schema
    const schema = Joi.object().keys({
        userID: Joi.any().required().label('User ID').error(errors => { return { message: "User ID is required." }; }),
        postTitle: Joi.any().optional().label('Post Title'),
        postType: Joi.any().required().label('Post Type').error(errors => { return { message: "Post Type is required." }; }),
        postDescription: Joi.any().optional().label('Post Description'),
    });

    // validate the request data against the schema
    const validateResult = Joi.validate(requestedData, schema, (err, value) => {
        return err;
    });
    if (validateResult) {
        return res.status(400).json({
            status: 400,
            message: "Bad Request",
            detailedMessage: validateResult.details[0].message
        });
    }
    Post.addPost(fileName, requestedData).then((responseData) => res.json(responseData)).
        catch((err) => next(err));
}

module.exports.getAllPosts = (req, res, next) => {
    //@ start validation

    let postType = req.query && req.query.postType ? req.query.postType : "";

    Post.getAllPostsDetails(postType).then((responseData) => res.json(responseData)).
        catch((err) => next(err));
}

module.exports.updatePostDetail = (req, res, next) => {
    //@ start validation
    let requestedData = req.body;
    // define the validation schema
    const schema = Joi.object().keys({
        postId: Joi.any().optional().label('Post Id').error(errors => { return { message: "Post ID is required." }; }),
        postTitle: Joi.any().optional().label('Post Title'),
        postDescription: Joi.any().optional().label('Post Description'),
        postType: Joi.any().optional().label('Post Type'),

    });

    // validate the request data against the schema
    const validateResult = Joi.validate(requestedData, schema, (err, value) => {
        return err;
    });
    if (validateResult) {
        return res.status(400).json({
            status: 400,
            message: "Bad Request",
            detailedMessage: validateResult.details[0].message
        });
    }
    Post.postUpdate(requestedData).then((responseData) => res.json(responseData)).
        catch((err) => next(err));
}

module.exports.postDelete = (req, res, next) => {
    //@ start validation
    let requestedData = req.params;
    // define the validation schema
    const schema = Joi.object().keys({
        postId: Joi.any().optional().label('Post Id').error(errors => { return { message: "Post ID is required." }; }),
    });

    // validate the request data against the schema
    const validateResult = Joi.validate(requestedData, schema, (err, value) => {
        return err;
    });
    if (validateResult) {
        return res.status(400).json({
            status: 400,
            message: "Bad Request",
            detailedMessage: validateResult.details[0].message
        });
    }
    Post.deletePost(requestedData).then((responseData) => res.json(responseData)).
        catch((err) => next(err));
}