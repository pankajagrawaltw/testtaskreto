module.exports.storage = () => {
    const path = require("path");
    const multer = require('multer');
    const fs = require("fs");
    const uploadPath = path.resolve("./public/uploads");
    const storage = multer.diskStorage({
        destination: function (req, file, cb) {
            try {
                var currentDate = new Date();
                var currentMonth = currentDate.getMonth() + 1;

                currentMonth = currentMonth <= 9 ? "0" + currentMonth : currentMonth;
                var currentDay = currentDate.getDate();
                currentDay = currentDay <= 9 ? "0" + currentDay : currentDay;
                var currentYear = currentDate.getFullYear();
                var filePath = uploadPath;


                // For folder attachment
                if (!fs.existsSync(filePath)) {
                    fs.mkdirSync(filePath);
                }

                // for current year
                filePath += "/" + currentYear;
                if (!fs.existsSync(filePath)) {
                    fs.mkdirSync(filePath);
                }

                // for current month
                filePath += "/" + currentMonth;
                if (!fs.existsSync(filePath)) {
                    fs.mkdirSync(filePath);
                }

                // for current day
                filePath += "/" + currentDay;
                if (!fs.existsSync(filePath)) {
                    fs.mkdirSync(filePath);
                }
                cb(null, filePath);
            } catch (e) {
                log(e);
            }
        },
        filename: function (req, file, cb) {
            file.extension = file.originalname.split(".")[
                file.originalname.split(".").length - 1
            ];
            var datetimestamp = Date.now();
            cb(
                null,
                file.originalname.split(".")[0] +
                "-" +
                datetimestamp +
                "." +
                file.originalname.split(".")[
                file.originalname.split(".").length - 1
                ]
            );
        }
    })

    let upload = multer({ storage })
    return upload
}