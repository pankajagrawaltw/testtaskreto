const { date } = require('joi');
const mongoose = require('mongoose');
const PostSchema = mongoose.Schema({
    userID: {
        type: String,
    },
    postTitle: {
        type: String,
    },
    postDescription: {
        type: String,
        default: ''
    },
    postType: {
        type: String,
    },
    postImage: {
        type: String,
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
},
    {
        timestamps: true
    });

module.exports = mongoose.model('Post', PostSchema);