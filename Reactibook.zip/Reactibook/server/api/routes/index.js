const express = require("express");
const router = express.Router();
const Post = require('../validations/post');
const { userAuthenticator } = require('../middleware/index');
const filePath = require('../middleware/fileUpload')
const upload = filePath.storage()


//Post Routes
router.post("/addPost", upload.single('filename'), userAuthenticator, Post.createPost);
router.get("/getAllPosts", userAuthenticator, Post.getAllPosts);
router.put("/UpdatePostDetails", [userAuthenticator], Post.updatePostDetail);
router.delete("/deletePost/:postId", [userAuthenticator], Post.postDelete);

module.exports = router;