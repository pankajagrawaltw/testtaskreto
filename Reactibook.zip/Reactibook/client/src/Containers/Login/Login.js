import React, { useState } from 'react'
import { toast, ToastContainer } from 'react-toastify';
import jwtDecode from 'jwt-decode';
import firebase from "../../FireBase";
import { setItemLocalStorage } from '../../Utils/LocalStorage'
import LoginForm from '../../Components/LoginForm/LoginForm'




function Login({ history }) {

    const [loginEmail, setLoginEmail] = useState("");
    const [loginPass, setLoginPass] = useState("");
    const [emailError, setEmailError] = useState('')
    const [passError, setPassError] = useState('')

    const onChangeEmail = (e) => {
        setLoginEmail(e.target.value)
        emailValidation(e.target.value)
    }
    const onChangePass = (e) => {
        setLoginPass(e.target.value)
        validatePass(e.target.value)
    }
    const emailValidation = (email) => {
        let errorText = "";
        const emailReg = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
        if (!emailReg.test(email)) {
            errorText = 'Debe ser una dirección de correo electrónico válida'
        }
        if (!email) {
            errorText = 'Correo electronico es requerido'
        }
        setEmailError(errorText)
        return errorText ? true : false;
    }


    const validatePass = (pass) => {
        let errorText = "";
        if (!pass) {
            errorText = 'Se requiere contraseña'
        }
        setPassError(errorText)
        return errorText ? true : false;
    }


    const login = async (e) => {

        e.preventDefault()

        const isValidEmail = emailValidation(loginEmail);
        const isValidPass = validatePass(loginPass)

        if (isValidEmail || isValidPass) {

            return
        }


        await firebase
            .auth()
            .signInWithEmailAndPassword(loginEmail, loginPass)
            .then((user) => {

                firebase.auth().currentUser.getIdToken(/* forceRefresh */ true).then((idToken) => {

                    const user = jwtDecode(idToken);

                    setItemLocalStorage('accessToken', idToken)
                    setItemLocalStorage('userID', JSON.stringify(user.user_id))

                    toast('Conectado con éxito', {
                        type: "success"
                    })
                    history.push('/create-post')

                }).catch((error) => {
                });

            })
            .catch((err) => {
            });

    };

    return (
        <>
            <LoginForm
                onLogin={login}
                loginEmail={loginEmail}
                loginPass={loginPass}
                emailError={emailError}
                passError={passError}
                onChangeEmail={(e) => onChangeEmail(e)}
                onChangePass={(e) => onChangePass(e)} />
            <ToastContainer />
        </>
    )
}

export default Login
