import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { toast, ToastContainer } from 'react-toastify';
import * as APIs from '../../Utils/ApiUrls'
import { getItemLocalStorage } from "../../Utils/LocalStorage";
import Header from '../../Components/Header/Header'
import './CreatePost.style.css'
import FriendsAndPublicTab from '../../Components/Friends&PublicTab/Friends&PublicTab'
import DropDown from '../../Components/DropDown/DropDown'
import Button from '../../Components/Button/Button'
import EditModalComponent from '../../Components/Modal/EditModal'
import DeleteModalComponent from '../../Components/Modal/DeleteModal'

function CreatePost() {

    const APIToken = getItemLocalStorage("accessToken");
    const [images, setImages] = useState({});
    const [description, setDescription] = useState('')
    const [descriptionError, setDescriptionError] = useState('')
    const [dropDownValue, setDropDownValue] = useState('friend')
    const [friendType, setFriendType] = useState('friend')
    const [publicType, setPublicType] = useState('')
    const [friendTabData, setFriendTabData] = useState('')
    const [filename, setFileName] = useState('')
    const [publicTabData, setPublicTabData] = useState('')
    const [isOpenEditModal, setIsOpenEditModal] = useState(false)
    const [isOpenDeleteModal, setIsOpenDeleteModal] = useState(false)
    const [deletePostID, setDeletePostID] = useState('')
    const [postData, setPostData] = useState({})
    const [imageFiles, setImageFiles] = useState([])


    useEffect(() => {
        onSetTypeFriend()
    }, [])

    const validateDescription = (desc) => {

        let errorText = "";
        if (!desc) {
            errorText = 'Se requiere descripción'
        }
        setDescriptionError(errorText)
        return errorText ? true : false;
    }



    const onSetTypeFriend = () => {

        setFriendType('friend')
        setPublicType(null)
        getPostFriend()
    }


    const onSetTypePublic = () => {

        setPublicType('public')
        setFriendType(null)
        getPostPublic()
    }

    const onChangeImage = e => {

        const files = Array.from(e.target.files)
        setImageFiles(files);
        files.forEach((file, i) => {

            setImages(file)
            setFileName(file.name)
        })

    }


    const getPostFriend = () => {

        axios.get(APIs.GET_ALL_POSTS_FRIEND_URL, {
            headers: {
                'token': `${APIToken}`
            }
        })
            .then(res => {
                setFriendTabData(res.data.data)
            })
            .catch(error => {
                toast(error.message, {
                    type: 'error'
                })
            });
    }


    const getPostPublic = () => {


        axios.get(APIs.GET_ALL_POSTS_PUBLIC_URL, {
            headers: {
                'token': `${APIToken}`
            }
        })
            .then(res => {
                setPublicTabData(res.data.data)
            })
            .catch(error => {
                toast(error.message, {
                    type: 'error'
                })
            });
    }



    const createPost = () => {


        if (description === "") {
            toast("Ingrese una descripción válida", {
                type: 'info'
            })
        } else if (imageFiles.length === 0) {
            toast("Por favor seleccione una imagen", {
                type: 'info'
            })
        } else {

            const userId = getItemLocalStorage('userID')
            const parseID = JSON.parse(userId)
            const formData = new FormData()


            formData.append('userID', parseID)
            formData.append('postDescription', description)
            formData.append('filename', images)
            formData.append('postType', dropDownValue)

            axios.post(APIs.CREATE_POST_URL, formData, {
                headers: {
                    'token': `${APIToken}`
                }
            })
                .then(response => {

                    toast(response.data.message, {
                        type: 'success'
                    })
                    getPostFriend()
                    getPostPublic()
                    setDescription('')
                    setImageFiles([])
                    setFileName('')
                })
                .catch(error => {
                    toast(error.message, {
                        type: 'error'
                    })
                });
        }

    }


    const onEditFriendPost = () => {

        const postId = postData && postData._id

        let reqBody = {
            "postId": postId,
            "postDescription": description,
            "postType": postData && postData.postType
        }

        axios.put(APIs.UPDATE_POST_URL, reqBody, {
            headers: {
                'token': `${APIToken}`
            }
        })
            .then(res => {
                toast(res.data.message, {
                    type: 'success'
                })

                onCloseEditModal()
                getPostFriend()
                setDescription('')
            })
            .catch(error => {
                toast(error.message, {
                    type: 'error'
                })
            });

    }

    const onEditPublicPost = () => {

        const postId = postData && postData._id

        let reqBody = {
            "postId": postId,
            "postDescription": description,
            "postType": postData && postData.postType
        }

        axios.put(APIs.UPDATE_POST_URL, reqBody, {
            headers: {
                'token': `${APIToken}`
            }
        })
            .then(res => {
                toast(res.data.message, {
                    type: 'success'
                })

                getPostPublic()
                onCloseEditModal()
                setDescription('')
            })
            .catch(error => {
                toast(error.message, {
                    type: 'error'
                })
            });

    }

    const onDeletePost = () => {


        axios.delete(APIs.DELETE_POST_URL + deletePostID, {
            headers: {
                'token': `${APIToken}`
            }
        })
            .then(res => {

                toast(res.data.message, {
                    type: 'success'
                })

                closeDeleteModal()
                getPostFriend()
                getPostPublic()
            })
            .catch(error => {
                toast(error.message, {
                    type: 'error'
                })

            });
    }

    const onChangeDropdownValue = (e) => {
        setDropDownValue(e.target.value)

    }

    const onChangeDescription = (e) => {
        setDescription(e.target.value)
        validateDescription(e.target.value)
    }

    const openEditModal = (data) => {
        setPostData(data)
        setIsOpenEditModal(true)
    }

    const openDeleteModal = (postId) => {
        setDeletePostID(postId)
        setIsOpenDeleteModal(true)
    }

    const onCloseEditModal = () => {
        setIsOpenEditModal(false)
        setDescription('')

    }
    const closeDeleteModal = () => {
        setIsOpenDeleteModal(false)
        setDeletePostID(null)
    }


    return (
        <>
            <Header />
            <section className="post-div">
                <div className="container">
                    <div className="row">
                        <div className="col-md-6" id="smoth-scroll">
                            <div className="row">
                                <div className="col-md-12">

                                    <div className="">
                                        <div className="outside-border">
                                            <textarea className="form-control"
                                                value={description || ''}
                                                placeholder='¿Qué está pasando?'
                                                onChange={(e) => onChangeDescription(e)}>

                                            </textarea>
                                            <div className='description-error'>
                                                {descriptionError}
                                            </div>
                                            <ul className="list-unstyled list-inline pt-4 float-left file-relative">
                                                <li className="list-inline-item">
                                                    <button className='btn link-text'>
                                                        <i className='fa fa-picture-o pr-2'>
                                                        </i>
                                                        foto
                                                    <input
                                                            className="input-opacityfile"
                                                            type="file"
                                                            onChange={(e) => onChangeImage(e)}
                                                        />
                                                    </button>
                                                    <div className='select-imgtext pt-1'>
                                                        {images && filename}
                                                    </div>
                                                </li>
                                            </ul>
                                            <DropDown
                                                selectedValue={dropDownValue}
                                                onChangeOption={(e) => onChangeDropdownValue(e)}
                                            />
                                            <div className='public-btndiv'>
                                                <Button
                                                    className='btn public-btn btn-primary'
                                                    title='publicar'
                                                    onClick={createPost} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-md-12' >
                                    <div id="tab-bg">
                                        <FriendsAndPublicTab
                                            isOpen={isOpenEditModal}
                                            onClickEditFriend={(data) => openEditModal(data)}
                                            friendTabData={friendTabData}
                                            publicTabData={publicTabData}
                                            friendType={friendType}
                                            publicType={publicType}
                                            onDelete={(postId) => openDeleteModal(postId)}
                                            onSetTypeFriend={onSetTypeFriend}
                                            onSetTypePublic={onSetTypePublic}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6 fixed-position">
                            <div className="bg-img">
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <EditModalComponent
                isOpen={isOpenEditModal}
                onCloseModal={onCloseEditModal}
                onClickSave={friendType === 'friend' ? onEditFriendPost : onEditPublicPost}
                onChangeDescription={(e) => onChangeDescription(e)}
                modalData={postData} />

            <DeleteModalComponent
                open={isOpenDeleteModal}
                onClose={closeDeleteModal}
                deletePost={onDeletePost} />
            <ToastContainer />
        </>
    )
}

export default CreatePost
