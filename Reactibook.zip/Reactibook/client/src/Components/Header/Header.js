import React from 'react'
import './Header.style.css'

function Header() {
    return (
        <header className="header" >
            <div className="container-fluid">
                <nav className="navbar navbar-expand-md navbar-light">
                    <span className="navbar-brand">
                        Reactibook
                   </span>
                    <ul className="navbar-nav ml-auto">
                        <li className="nav-item ">
                        </li>
                    </ul>
                </nav>
            </div>
        </header>
    )
}
export default Header

