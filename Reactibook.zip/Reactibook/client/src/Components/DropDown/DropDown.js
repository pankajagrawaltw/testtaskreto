import React from 'react'

function DropDown({ selectedValue, onChangeOption }) {
    return (
        <div className="float-right">
            <div className="form-group width">
                <select
                    className="custom-select"
                    id="lead-select"
                    defaultValue={selectedValue}
                    onChange={(e) => onChangeOption(e)}
                >
                    <option value='friend'>Amigos</option>
                    <option value="public">Público</option>
                </select>
            </div>
          
        </div>
    )
}

export default DropDown
