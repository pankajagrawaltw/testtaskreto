import React from 'react'
import './Button.style.css'

function Button({ title, onClick, className, deleteIcon, editIcon, photoVideo,closeIcon }) {
    return (
        <button
            className={className}
            onClick={onClick}>
            {closeIcon && <i className="fa fa-close"></i>}
            {editIcon && <i className="fa fa-pencil pr-1"></i>}
            {deleteIcon && <i className="fa fa-trash pr-1"></i>}
            {photoVideo &&  <i className="fa fa-picture-o"></i>}
            {title}
        </button>
    )
}

export default Button
