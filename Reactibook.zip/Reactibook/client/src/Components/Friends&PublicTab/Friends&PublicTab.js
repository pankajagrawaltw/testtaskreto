import React from 'react'
import './Friends&PublicTab.style.css'
import Button from '../Button/Button'

function FriendsAndPublicTab({
    friendTabData,
    publicTabData,
    friendType,
    publicType,
    onSetTypeFriend,
    onSetTypePublic,
    onClickEditFriend,
    onDelete }) {



    const renderFriendsTabData = () => {

        if (friendTabData) {
            return friendTabData.map((data, i) => (

                <div className="tab-pane create-posttabs" key={i}>
                    <div className="content-bg mb-2" >

                        <p>{data && data.postDescription}</p>


                        <img alt='' src={data && data.postImage} width="100%;" className="mb-3" />
                        <ul className="list-unstyled list-inline bottom-border">
                            <li className="list-inline-item">
                                <Button
                                    className='edit-link btn'
                                    title='Editar'
                                    editIcon={true}
                                    onClick={() => onClickEditFriend(data)} />
                            </li>
                            <li className="list-inline-item">
                                <Button
                                    className='delete-link btn'
                                    title='Eliminar'
                                    onClick={() => onDelete(data._id)}
                                    deleteIcon={true} />
                            </li>
                        </ul>
                    </div>
                </div>
            ))
        }

    }


    const renderPublicTabData = () => {

        if (publicTabData) {
            return publicTabData.map((data, i) => (

                <div className="tab-pane active create-posttabs" id="tabs-1" key={i}>
                    <div className="content-bg mb-2">
                        <p>{data && data.postDescription}</p>
                        <img alt='' src={data.postImage} width="100%;" className="mb-3" />
                        <ul className="list-unstyled list-inline bottom-border">
                            <li className="list-inline-item">
                                <Button
                                    className='edit-link btn'
                                    title='Editar'
                                    editIcon={true}
                                    onClick={() => onClickEditFriend(data)} />
                            </li>
                            <li className="list-inline-item">
                                <Button
                                    className='delete-link btn'
                                    title='Eliminar'
                                    onClick={() => onDelete(data._id)}
                                    deleteIcon={true}
                                />
                            </li>
                        </ul>
                    </div>
                </div>
            ))
        }

    }
    const renderTab = () => {

        if (friendType === 'friend') {

            return renderFriendsTabData()

        } else if (publicType === 'public') {

            return renderPublicTabData()
        }
    }

    const renderEmptyTabDataMsg = () => {

        if (publicType === 'public' && publicTabData.length === 0) {

            return <div className='emptyMsg'> No hay publicaciones públicas disponibles </div>

        } else if (friendType === 'friend' && friendTabData.length === 0) {

            return <div className='emptyMsg'> No hay publicación de amigas disponible </div>
        }
    }

    return (
        <div>
            <div className=" create-posttabs" >
                <div className="nav nav-tabs">
                    <div className="nav-item">
                        <Button
                            title='Público'
                            className={publicType === 'public' ? "nav-link active" : 'nav-link'}
                            onClick={onSetTypePublic} />
                    </div>
                    <div className="nav-item">
                        <Button
                            title='Amigos'
                            className={friendType === 'friend' ? "nav-link active" : 'nav-link'}
                            onClick={onSetTypeFriend} />
                    </div>
                </div>
            </div>
            {renderTab()}
            {renderEmptyTabDataMsg()}
        </div>
    )
}
export default FriendsAndPublicTab