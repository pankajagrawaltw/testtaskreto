import React from 'react';
import Modal from 'react-modal';
import Button from '../Button/Button';
import './EditModal.style.css'




function EditModalComponent({
  isOpen,
  descriptionError,
  modalData,
  onCloseModal,
  onChangeDescription,
  onClickSave,
}) {
  if (modalData) {
    
    return (
      <Modal
        isOpen={isOpen}
        ariaHideApp={true}
        onRequestClose={onCloseModal}
        style={customStyles}
        contentLabel="Edit Modal"
        appElement={document.getElementById('app')}
      >

        <div className="tab-pane create-posttabs">
          <h4>Edit Post</h4>
          <div className="content-bg mb-2">
            <textarea
              className="form-control"
              defaultValue={modalData && modalData.postDescription}
              placeholder="¿Qué está pasando?"
              onChange={e => onChangeDescription (e)}
            />
            {descriptionError}
            <div className='modal-imgdiv'>
              <img
                alt=""
                src={modalData && modalData.postImage}
                width="100%;"
                className="mb-3"
              />
            </div>
           
            <ul className="list-unstyled list-inline bottom-border">
              <li className="list-inline-item">
                <Button
                  className="edit-link btn"
                  title="Save"
                  editIcon={true}
                  onClick={onClickSave}
                />
              </li>
              <li className="list-inline-item">
                <Button
                  onClick={onCloseModal}
                  className="delete-link btn"
                  title="Cancel"
                  deleteIcon={true}
                />
              </li>
            </ul>
          </div>
        </div>
      </Modal>
    );
  } else {
    return null;
  }
}

export default EditModalComponent;

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  },
};
