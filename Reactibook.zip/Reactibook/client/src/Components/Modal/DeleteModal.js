import React from 'react';
import Modal from 'react-modal';
import Button from '../Button/Button';
import './DeleteModal.style.css'



function DeleteModalComponent({
  open,
  onClose,
  deletePost
}) {
  
    return (
      <Modal
        isOpen={open}
        ariaHideApp={true}
        onRequestClose={onClose}
        style={customStyles}
        contentLabel="Delete Modal"
        appElement={document.getElementById('app')}
      >
      <div>
       <p className='pb-3'>Are You sure you want to delete this post?</p>
        <div className='float-right delete-popupbtn'>
        <Button className='btn btn-primary mr-2' title='Yes' onClick={deletePost} />
        <Button className='btn btn-danger' title='No' onClick={onClose} />
        </div>
      </div>

        
      </Modal>
    );
  
}

export default DeleteModalComponent;

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  },
};
