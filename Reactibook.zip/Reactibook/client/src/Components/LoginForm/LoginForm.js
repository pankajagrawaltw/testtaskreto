import React from 'react'
import './LoginForm.style.css'
import loginImage from '../../Assets/images/login.png'
import Button from '../Button/Button'


function LoginForm({
    onLogin,
    loginEmail,
    loginPass,
    emailError,
    passError,
    onChangeEmail,
    onChangePass }) {
    return (

        <section className="login-form">
            <div className="container-fluid p-0">
                <div className="row">
                    <div className="">
                        <div className="content-div">
                            <h1 className="mb-0 text-center">Reactibook</h1>
                            <p className=" text-center">Let's do the timeline</p>
                            <div className="form-bg">
                                <form onSubmit={onLogin}>
                                    <h2 className="text-center">log In</h2>
                                    <label>Email</label>
                                    <input
                                        type="text"
                                        name=""
                                        value={loginEmail}
                                        onChange={(e) => onChangeEmail(e)}
                                        className="form-control"
                                        placeholder="Email" />
                                    <span className="error-msg">{emailError}</span>
                                    <br></br>
                                    <label className='mt-2'>Password</label>
                                    <input
                                        type="password"
                                        name=""
                                        value={loginPass}
                                        onChange={(e) => onChangePass(e)}
                                        className="form-control"
                                        placeholder="Password" />
                                    <span className="error-msg">{passError}</span>
                                    <div className="text-center">
                                        <Button className='btn btn-login btn-primary' title='Log In' onClick={onLogin} />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div className="right-div">
                        <div>
                            <img alt='loginImage' src={loginImage} width="100%" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default LoginForm
