
export const HOME = "/"
export const LOGIN = "/login"
export const CREATE_POST = "/create-post"
