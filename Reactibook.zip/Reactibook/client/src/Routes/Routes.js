import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import * as routes from './RoutesContants';
import Login from '../Containers/Login/Login'
import CreatePost from '../Containers/CreatePost/CreatePost'


const Routes = () => {
  return (
    <BrowserRouter>
      <Switch>
      <Route exact
          path={routes.HOME}
          component={Login} />
        <Route exact
          path={routes.LOGIN}
          component={Login} />

        <Route exact
          path={routes.CREATE_POST}
          component={CreatePost}
        />
      </Switch>
    </BrowserRouter>
  );
};
export default Routes