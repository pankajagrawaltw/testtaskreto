export const setItemLocalStorage = (key, value) => {
    localStorage.setItem(key, value);
  };
  export const getItemLocalStorage = (key) => {
    let token = key ? localStorage.getItem(key) : "";
    return token;
  };
  export const removeItemLocalStorage= (key) => {
    localStorage.removeItem(key)
  };