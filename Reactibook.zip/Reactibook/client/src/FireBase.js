
import firebase from "firebase/app";
import "firebase/auth";

// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyDpkXm72qPeZmpSwAYKQyDnWk_mk1KsP9M",
    authDomain: "reactibook-84465.firebaseapp.com",
    projectId: "reactibook-84465",
    storageBucket: "reactibook-84465.appspot.com",
    messagingSenderId: "135120201162",
    appId: "1:135120201162:web:dfa7b2baab159d07419b33",
    measurementId: "G-YSYCQ4PQB1"
};
// Initialize Firebase
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

export default firebase;

