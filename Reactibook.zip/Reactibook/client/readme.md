
Front- End server Url  http://localhost:3000

How To Run  Front-End Server

1) Install dependencies run command in client folder

npm install or yarn install


2) To Start Front-End Server
npm start or yarn start
